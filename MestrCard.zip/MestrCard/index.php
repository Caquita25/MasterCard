<?php
$src="ar";
header("location:$src");
?>
