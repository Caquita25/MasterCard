<?php 
$yourmail = "alergio644@gmail.com" ; 
?>